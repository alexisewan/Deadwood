public class SceneCards {
   private String cardName;
   private int budget;
   private int sceneNum;
   private String sceneDesc;
   private Roles[] roles;
   private String pngLocation = "card_";

   public void SceneCards(String name, int budget, int sceneNum, String sceneDesc, Roles[] roles, String cardNum) {
      this.cardName = name;
      this.budget = budget;
      this.sceneNum = sceneNum;
      this.sceneDesc = sceneDesc;
      this.roles = roles;
      this.pngLocation += cardNum;
   }

   public int getBudget() {
      return this.budget;
   }

   public Roles[] getRoles() {
      return this.roles;
   }

   public String getPNGLocation(){
      return this.pngLocation;
   }

   // compares the given integer, check, to the budget and returns whether or not
   // the check is >,=,or < the budget
   public String checkVSBudget(int check) {
      String returnString;
      if (check < this.budget) {
         returnString = "less";
      } else if (check == this.budget) {
         returnString = "equal";
      } else {
         returnString = "greater";
      }
      return returnString;
   }

   public void printCard() {
      System.out.print(cardName + " ");
      System.out.print(budget + " ");
      System.out.print(sceneNum + " ");
      System.out.print(sceneDesc + " ");
      for (int i = 0; i < roles.length; i++) {
         Roles role = roles[i];
         role.printRole();
      }
   }

   public void displayTitle() {

   }

   public void displayRole() {

   }
}
