public class Player {
   String name;
   int money;
   int credits;
   int rank;
   int rehearsals = 0;
   int points;
   String currentSet = null;
   Roles role = null;
   String oldSet;
   String dieColor;

   public void Player(String name, int money, int credits, int rank) {
      this.name = name;
      this.money = money;
      this.credits = credits;
      this.rank = rank;
   }

   public int getCredits() {
      return this.credits;
   }

   public void setCredits(int credits) {
      this.credits = credits;
   }

   public String getDieColor() {
      return this.dieColor;
   }

   public void setDieColor(String color) {
      this.dieColor = color;
   }

   public int getMoney() {
      return this.money;
   }

   public void setMoney(int money) {
      this.money = money;
   }

   public Roles getRole() {
      return this.role;
   }

   public void setRole(Roles role) {
      this.role = role;
   }

   public String getName() {
      return this.name;
   }

   public String getSet() {
      return this.currentSet;
   }

   public int getRehearsals() {
      return this.rehearsals;
   }

   public int getRank() {
      return this.rank;
   }

   public void setRank(int rank) {
      this.rank = rank;
   }

   public void addRehearsals() {
      this.rehearsals++;
   }

   public String getOldSet() {
      return this.oldSet;
   }

   public int getPoints() {
      return this.points;
   }

   public void displayPlayer() {
      System.out.println(name + " has $" + money + ", " + credits + " credits, and a rank of " + rank + ".");
      if (currentSet != null) {
         System.out.println(name + " is at the " + currentSet + " set.");
      }
      if (role != null) {
         String lines = this.role.getLine();
         System.out.printf("They are playing as " + role.getName() + ". Their lines are: " + lines);
      }
      System.out.println();
   }

   public String moveToSet(String set) {
      if (currentSet == null) {
         System.out.println("Moved " + this.name + " to the " + set + " set.");
         this.currentSet = set;
         oldSet = currentSet;
      } else {
         oldSet = currentSet;
         this.currentSet = set;
         System.out.println("Moved " + this.name + " from the " + oldSet + " set to the " + currentSet + " set.");
      }
      return oldSet;
   }

   public boolean roleTaken(Player[] playerArray, String userInput, Roles newRole) {
     for (int i = 0; i < playerArray.length; i++) {
       if (playerArray[i].getRole() != null) {
         if ((playerArray[i].getRole().equals(newRole))) {
           return false;
         }
       }
     }
     return true;
   }

   public void takeRole(Roles role) {
      this.role = role;
   }

   public void takePayment(String currency, int payment) {
      if (currency.equals("money")) {
         money += payment;
      } else if (currency.equals("credits")) {
         credits += payment;
      }
   }

   public int calculateScore() {
      points += credits;
      points += money;
      points += rank * 5;
      return points;
   }
}
