import java.util.*;

public class Bank {

   public void payActors(ArrayList<Player> players, int[] revenue) {
      ArrayList<Player> leadActors = new ArrayList<Player>();
      // for each player on the set
      for (int i = 0; i < players.size(); i++) {
         Player player = players.get(i);
         Roles playerRole = player.getRole();

         // paying set-actors and queueing card-actors
         if (playerRole != null) {
            if (playerRole.getType().equals("set")) {
               int payment = playerRole.getRoleRank();
               player.takePayment("money", payment);
            } else if (playerRole.getType().equals("card")) {
               leadActors.add(player);
            }
         }
      }

      Player[] cardActors = new Player[leadActors.size()];
      for (int i = 0; i < leadActors.size(); i++) {
         cardActors[i] = leadActors.get(i);
      }
      // using insertion sort to sort the player array.
      // implementation of insertion sort adpated from
      // https://www.javatpoint.com/insertion-sort-in-java
      for (int j = 1; j < cardActors.length; j++) {
         Player sorting = cardActors[j];
         int i = j - 1;
         while (sorting.getRole().getRoleRank() < cardActors[i].getRole().getRoleRank() && i > -1) {
            cardActors[i + 1] = cardActors[i];
            i--;
         }
         cardActors[i + 1] = sorting;
      }
      // paying each lead actor with the wrap-around rules
      int currActor = cardActors.length - 1;
      for (int k = 0; k < revenue.length; k++) {
         if (currActor < 0) {
            currActor = cardActors.length - 1;
         }
         if (currActor >= 0) {
            cardActors[currActor].takePayment("money", revenue[k]);
         }
      }
   }
}
