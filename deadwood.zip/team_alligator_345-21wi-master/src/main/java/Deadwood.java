import java.io.*;
import java.util.*;
import java.lang.*;
import java.nio.channels.AlreadyBoundException;
import java.text.*;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

public class Deadwood {
    // initializing global static variables
    private static int numDays = 4;
    private static ArrayList<SceneCards> sceneCards = new ArrayList<SceneCards>();
    private static ArrayList<Sets> sets = new ArrayList<Sets>();
    private static CastingOffice castingOfficeSet;
    private int numPlayers;
    private static String[] playerNames;
    private static Player[] playerArray;

    public static void main(String[] args) {

        // initializing an instance of scanner
        Scanner input = new Scanner(System.in);
        DeadwoodController controller = new DeadwoodController();
        // setting board and card XML paths
        String boardPath = null;
        String cardPath = null;

        if (args.length >= 2) {
            boardPath = args[0];
            cardPath = args[1];
        } else {
            // change back: src/main/resources/
            boardPath = "board.xml";
            cardPath = "cards.xml";
        }
        // get number of players
        int numPlayers = controller.getPlayers();

        int startingMoney = 0;
        int startingCredits = 0;
        int startingRank = 1;

        // find special rules
        if (numPlayers == 2 || numPlayers == 3) {
            // only play 3 days
            numDays = 3;
        } else if (numPlayers == 5) {
            // each player starts with 2 credits
            startingCredits = 2;
        } else if (numPlayers == 6) {
            // each player starts wit 4 credits
            startingCredits = 4;
        } else if (numPlayers == 7 || numPlayers == 8) {
            // each player starts at rank 2
            startingRank = 2;
        }

        playerArray = new Player[numPlayers];
        // initialize each player
        for (int i = 0; i < numPlayers; i++) {
            Player newPlayer = new Player();

            String name = controller.getName();

            newPlayer.Player(name, startingMoney, startingCredits, startingRank);

            playerArray[i] = newPlayer;
        }
        Player activePlayer = playerArray[0];

        //runs the window for the game
        controller.runGUI(numPlayers, activePlayer, playerArray);

        // initalize all the sets
        try {
            Document board = getDocFromFile(boardPath);
            initializeSets(board);

        } catch (NullPointerException e) {
            controller.printMessage("Error = " + e);
        } catch (Exception e) {
            controller.printMessage("Error = " + e);
        }

        // initialize all the scene cards
        try {
            Document cards = getDocFromFile(cardPath);
            initializeCards(cards);
        } catch (NullPointerException e) {
            controller.printMessage("Error = " + e);
        } catch (Exception e) {
            controller.printMessage("Error = " + e);
        }

        // STARTING GAME
        controller.addDice(playerArray, sets.get(0).getWholePlacementArray());
        while (numDays > 0) {
            // call dealNewScenes
            sets.get(0).dealNewScenes(sets, sceneCards, controller);

            //initializing player dice
            for (int i = 0; i < numPlayers; i++) {
                int occupancy = sets.get(0).getOccupancy();
                int[] playerPlacement = sets.get(0).getPlayerPlacement(occupancy);
                controller.move(playerArray[i], playerArray, playerPlacement);

                String oldSet = playerArray[i].moveToSet("trailer");
                if (!oldSet.equals("trailer")) {
                    sets.get(0).removePlayer(playerArray[i]);
                }
                sets.get(0).addPlayer(playerArray[i]);
            }

            //managing turns
            handleTurns(input, playerArray, activePlayer, controller);
            numDays--;
            if (numDays > 0) {
                controller.printMessage("It is the end of the day! Onto day " + numDays);
            }
        }

        // calculating the scores
        controller.printMessage("It is the end of the game. Calculating scores...");
        int[] scores = new int[playerArray.length];
        for (int i = 0; i < playerArray.length; i++) {
            scores[i] = playerArray[i].calculateScore();
        }

        // using insertion sort to sort the revenue array
        // implementation of insertion sort adpated from
        // https://www.javatpoint.com/insertion-sort-in-java
        for (int j = 1; j < scores.length; j++) {
            int sorting = scores[j];
            int i = j - 1;
            while ((i > -1) && sorting < scores[i]) {
                scores[i + 1] = scores[i];
                i--;
            }
            scores[i + 1] = sorting;
        }
        // printing the winners!
        int winningScore = scores[scores.length - 1];
        for (int i = 0; i < playerArray.length; i++) {
            if (playerArray[i].getPoints() == winningScore) {
                controller.printMessage(playerArray[i].getName() + " won!!");
            }
        }
    }

    public void setNumPlayers(int numPlayers) {
        this.numPlayers = numPlayers;
    }

    public void setPlayerNames(String[] playerNames) {
        this.playerNames = playerNames;
    }

    // building a document from the XML file
    // returns a Document object after loading the xml file.
    public static Document getDocFromFile(String filename) throws ParserConfigurationException {
        {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            DocumentBuilder db = dbf.newDocumentBuilder();
            Document doc = null;

            try {
                doc = db.parse(filename);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            return doc;
        } // exception handling
    }

    // initializing sets
    public static void initializeSets(Document setsDoc) {
        // initializing variables
        String setName;
        String[] adjacentSets = null;
        String adjSet;
        ArrayList<int[]> takes = new ArrayList<int[]>();
        int[] setArea = null;

        int upgradeRank;
        String currency;
        int price;

        Roles[] roles = null;
        String partName;
        int partRank;
        String line;
        String roleType;

        Element root = setsDoc.getDocumentElement();

        // setting up the trailer
        NodeList trailers = root.getElementsByTagName("trailer");
        Element trailer = (Element) trailers.item(0);
        NodeList trailerNeighbors = trailer.getElementsByTagName("neighbor");
        if (adjacentSets == null) {
            adjacentSets = new String[trailerNeighbors.getLength()];
        }
        for (int k = 0; k < trailerNeighbors.getLength(); k++) {
            // add each neighbor to the adjacency list for this set
            Element trailerNeighbor = (Element) trailerNeighbors.item(k);
            adjacentSets[k] = trailerNeighbor.getAttribute("name");
        }
        setName = "trailer";

        // adding set location and dimensions
        NodeList area = trailer.getElementsByTagName("area");
        Element getDim = (Element) area.item(0);
        setArea = new int[4];

        setArea[0] = (Integer.parseInt(getDim.getAttribute("x")) * 2 / 3);
        setArea[1] = (Integer.parseInt(getDim.getAttribute("y")) * 2 / 3);
        setArea[2] = (Integer.parseInt(getDim.getAttribute("h")) * 2 / 3);
        setArea[3] = (Integer.parseInt(getDim.getAttribute("w")) * 2 / 3);

        // creating a trailer object and adding it to sets
        Sets newSet = new Sets();
        newSet.Sets(setName, adjacentSets, takes, roles, setArea);
        sets.add(newSet);

        adjacentSets = null;
        takes = new ArrayList<int[]>();
        setArea = null;

        // setting up casting office
        NodeList office = root.getElementsByTagName("office");
        Element castingOffice = (Element) office.item(0);

        // getting office neighbors
        NodeList officeNeighbors = castingOffice.getElementsByTagName("neighbor");
        if (adjacentSets == null) {
            adjacentSets = new String[officeNeighbors.getLength()];
        }
        for (int m = 0; m < trailerNeighbors.getLength(); m++) {
            // add each neighbor to the adjacency list
            Element officeNeighbor = (Element) officeNeighbors.item(m);
            adjacentSets[m] = officeNeighbor.getAttribute("name");
        }

        // getting dimensions and location of the office
        NodeList areas = castingOffice.getElementsByTagName("area");
        getDim = (Element) areas.item(0);
        int[] officeArea = new int[4];
        officeArea[0] = (Integer.parseInt(getDim.getAttribute("x")) * 2 / 3);
        officeArea[1] = (Integer.parseInt(getDim.getAttribute("y")) * 2 / 3);
        officeArea[2] = (Integer.parseInt(getDim.getAttribute("h")) * 2 / 3);
        officeArea[3] = (Integer.parseInt(getDim.getAttribute("w")) * 2 / 3);

        // creating a new castingOffice object
        castingOfficeSet = new CastingOffice();
        castingOfficeSet.CastingOffice(adjacentSets, officeArea);
        adjacentSets = null;
        officeArea = null;

        // getting office upgrades
        NodeList upgrades = castingOffice.getElementsByTagName("upgrade");
        for (int l = 0; l < upgrades.getLength(); l++) {
            Element upgrade = (Element) upgrades.item(l);
            upgradeRank = Integer.parseInt(upgrade.getAttribute("level"));
            currency = upgrade.getAttribute("currency");
            price = Integer.parseInt(upgrade.getAttribute("amt"));

            // adding set location and dimensions
            areas = upgrade.getElementsByTagName("area");
            getDim = (Element) areas.item(0);
            officeArea = new int[5];
            officeArea[0] = upgradeRank;
            officeArea[1] = (Integer.parseInt(getDim.getAttribute("x")) * 2 / 3);
            officeArea[2] = (Integer.parseInt(getDim.getAttribute("y")) * 2 / 3);
            officeArea[3] = (Integer.parseInt(getDim.getAttribute("h")) * 2 / 3);
            officeArea[4] = (Integer.parseInt(getDim.getAttribute("w")) * 2 / 3);

            castingOfficeSet.setRankValues(upgradeRank, currency, price, officeArea);
            officeArea = null;
        }

        // retrieving sets and adding them to the sets list
        NodeList setsList = root.getElementsByTagName("set");
        for (int i = 0; i < setsList.getLength(); i++) {
            Node set = setsList.item(i);
            Element currSet = (Element) set;
            setName = set.getAttributes().getNamedItem("name").getNodeValue();

            // adding set location and dimensions
            areas = currSet.getElementsByTagName("area");
            getDim = (Element) areas.item(0);
            setArea = new int[4];
            setArea[0] = (Integer.parseInt(getDim.getAttribute("x")) * 2 / 3);
            setArea[1] = (Integer.parseInt(getDim.getAttribute("y")) * 2 / 3);
            setArea[2] = (Integer.parseInt(getDim.getAttribute("h")) * 2 / 3);
            setArea[3] = (Integer.parseInt(getDim.getAttribute("w")) * 2 / 3);

            // getting neighbors
            NodeList neighbors = currSet.getElementsByTagName("neighbor");
            if (adjacentSets == null) {
                adjacentSets = new String[neighbors.getLength()];
            }
            // add each neighbor to the adjacency list for this set
            for (int k = 0; k < neighbors.getLength(); k++) {
                Element neighbor = (Element) neighbors.item(k);
                adjacentSets[k] = neighbor.getAttribute("name");
            }

            // getting takes
            NodeList getTakes = currSet.getElementsByTagName("take");
            for (int j = 0; j < getTakes.getLength(); j++) {
                int[] takesArea = new int[4];
                Element currTake = (Element) getTakes.item(j);
                NodeList takeAreas = currTake.getElementsByTagName("area");
                Element takeArea = (Element) takeAreas.item(0);
                takesArea[0] = (Integer.parseInt(takeArea.getAttribute("x")) * 2 / 3);
                takesArea[1] = (Integer.parseInt(takeArea.getAttribute("y")) * 2 / 3);
                takesArea[2] = (Integer.parseInt(takeArea.getAttribute("h")) * 2 / 3);
                takesArea[3] = (Integer.parseInt(takeArea.getAttribute("w")) * 2 / 3);

                takes.add(takesArea);
                takesArea = null;
            }

            // extracting parts and lines
            NodeList parts = currSet.getElementsByTagName("part");
            if (roles == null) {
                roles = new Roles[parts.getLength()];
            }
            for (int m = 0; m < parts.getLength(); m++) {
                Element part = (Element) parts.item(m);
                partName = part.getAttribute("name");
                partRank = Integer.parseInt(part.getAttribute("level"));

                // getting location and dimensions
                areas = part.getElementsByTagName("area");
                getDim = (Element) areas.item(0);
                int[] partArea = new int[4];
                partArea[0] = (Integer.parseInt(getDim.getAttribute("x")) * 2 / 3);
                partArea[1] = (Integer.parseInt(getDim.getAttribute("y")) * 2 / 3);
                partArea[2] = (Integer.parseInt(getDim.getAttribute("h")) * 2 / 3);
                partArea[3] = (Integer.parseInt(getDim.getAttribute("w")) * 2 / 3);

                // getting the lines
                NodeList lines = part.getElementsByTagName("line");
                Element getLine = (Element) lines.item(0);
                line = getLine.getTextContent();
                roleType = "set";
                // creating a role object and adding it to the roles array
                Roles newRole = new Roles();
                newRole.Roles(partName, partRank, line, roleType, partArea);
                roles[m] = newRole;
                partArea = null;
            }
            // creating each set object and adding it to the list
            newSet = new Sets();
            newSet.Sets(setName, adjacentSets, takes, roles, setArea);
            sets.add(newSet);
            adjacentSets = null;
            roles = null;
            takes = new ArrayList<int[]>();
            setArea = null;
        }
    }

    // initializing cards
    public static void initializeCards(Document cardsDoc) {
        // initializing variables for this method
        Element root = cardsDoc.getDocumentElement();
        NodeList cardsList = root.getElementsByTagName("card");
        String cardName;
        int budget;
        int sceneNum = 0;
        String sceneDesc = "";
        Roles[] roles = null;
        String cardNum;
        int[] area = new int[4];

        // for each card
        for (int i = 0; i < cardsList.getLength(); i++) {
            Node card = cardsList.item(i);
            Element currCard = (Element) card;
            cardName = card.getAttributes().getNamedItem("name").getNodeValue();
            cardNum = card.getAttributes().getNamedItem("img").getNodeValue();
            budget = Integer.parseInt(card.getAttributes().getNamedItem("budget").getNodeValue());

            // for each attribute on the card
            NodeList children = card.getChildNodes();
            for (int j = 0; j < children.getLength(); j++) {
                Node sub = children.item(j);
                // getting parts
                // extract parts and lines from children
                NodeList parts = currCard.getElementsByTagName("part");
                if (roles == null) {
                    roles = new Roles[parts.getLength()];
                }
                for (int m = 0; m < parts.getLength(); m++) {
                    Element part = (Element) parts.item(m);
                    String partName = part.getAttribute("name");
                    int partRank = Integer.parseInt(part.getAttribute("level"));

                    // getting location and dimensions
                    NodeList areas = part.getElementsByTagName("area");
                    Element getDim = (Element) areas.item(0);
                    area[0] = (Integer.parseInt(getDim.getAttribute("x")) * 2 / 3);
                    area[1] = (Integer.parseInt(getDim.getAttribute("y")) * 2 / 3);
                    area[2] = (Integer.parseInt(getDim.getAttribute("h")) * 2 / 3);
                    area[3] = (Integer.parseInt(getDim.getAttribute("w")) * 2 / 3);

                    // getting the lines
                    NodeList lines = part.getElementsByTagName("line");
                    Element getLine = (Element) lines.item(0);
                    String line = getLine.getTextContent();
                    String roleType = "card";
                    Roles newRole = new Roles();
                    newRole.Roles(partName, partRank, line, roleType, area);
                    roles[m] = newRole;
                }

                if ("scene".equals(sub.getNodeName())) {
                    sceneNum = Integer.parseInt(sub.getAttributes().getNamedItem("number").getNodeValue());
                    sceneDesc = sub.getTextContent();
                }
            }
            // adding each card to the sceneCards list
            SceneCards newScene = new SceneCards();
            newScene.SceneCards(cardName, budget, sceneNum, sceneDesc, roles, cardNum);
            sceneCards.add(newScene);
            roles = null;
        }
    }

    // finding the given set in the sets array
    public static Sets findSet(String set, ArrayList<Sets> sets) {
        for (int i = 0; i < sets.size(); i++) {
            if (sets.get(i).getName().equals(set)) {
                return sets.get(i);
            }
        }
        return null;
    }

    // makes and act check by rolling a die, checking it against the budget, and
    // paying actors accordingly.
    public static boolean makeActCheck(Player player, ArrayList<Sets> sets, DeadwoodController controller) {
        Dice dice = new Dice();
        if (player.getRole() != null) {
            Sets playerSet = findSet(player.getSet(), sets);
            if (playerSet.getSceneCard() != null) {
                int budget = playerSet.getSceneCard().getBudget();
                int roll = dice.diceRoll();
                roll += player.getRehearsals();
                if (roll >= budget) {
                    // paying actors
                    String printString = "Acting successful! You gained $";
                    if (player.getRole().getType().equals("card")) {
                        roll = dice.diceRoll();
                        player.takePayment("money", roll);
                        printString += roll + "!";
                    } else {
                        printString += "1 and 1 credit!";
                        player.takePayment("money", 1);
                        player.takePayment("credits", 1);
                    }
                    controller.printMessage(printString);
                    return true;
                } else {
                    controller.printMessage("Acting failed!");
                    return false;
                }
            } else {
                controller.printMessage("The scene has been wrapped!");
            }
        }
        return false;
    }

    // giving actor a rehearsal credit if they can have one.
    public static boolean rehearse(Player player, ArrayList<Sets> sets, DeadwoodController controller) {
        if (player.getRole() != null) {
            Sets playerSet = findSet(player.getSet(), sets);
            SceneCards currentCard = playerSet.getSceneCard();
            if (player.getRehearsals() != currentCard.getBudget()) {
                player.addRehearsals();
                return true;
            } else {
                controller.printMessage("You have enough rehearsals, you have to act.");
            }
        }
        return false;
    }

    // the main driver for each turn. Take user input and handles it accordingly
    // keeps track of the number of remaining scene cards so it knows when to end
    // the day, and calls the controller to manage the view. 
    public static void handleTurns(Scanner input, Player[] playerArray, Player activePlayer,
            DeadwoodController controller) {
        int numSceneCards = 10;
        boolean validInput = false;
        boolean movedAlready = false;
        boolean actedAlready = false;
        boolean rehearsedAlready = false;
        boolean tookRole = false;

        String[] options = null;

        while (numSceneCards > 1) {
            // getting turn options for the player
            if (activePlayer.getRole() != null) {
                //if they are in a role
                if (!tookRole && !actedAlready && !rehearsedAlready) {

                    options = new String[3];
                    options[0] = "act";
                    options[1] = "rehearse";
                    options[2] = "end";
                } else {
                    options = new String[1];
                    options[0] = "end";
                }
            } else if (activePlayer.getSet().equals("office")) {
                //if they are at the casting office
                if (movedAlready) {
                    options = new String[2];
                    options[0] = "upgrade";
                    options[1] = "end";
                } else {
                    options = new String[3];
                    options[0] = "move";
                    options[1] = "upgrade";
                    options[2] = "end";
                }
            } else if (activePlayer.getSet() != null) {
                //if they are free to move/take role
                Sets currentSet = findSet(activePlayer.getSet(), sets);
                if (currentSet.getSceneCard() != null) {
                    if (!movedAlready) {
                        options = new String[3];
                        options[0] = "move";
                        options[1] = "work";
                        options[2] = "end";
                    } else {
                        options = new String[2];
                        options[0] = "work";
                        options[1] = "end";
                    }
                }
                if (currentSet.getSceneCard() == null) {
                    //if scene is wrapped
                    if (!movedAlready) {
                        options = new String[2];
                        options[0] = "move";
                        options[1] = "end";
                    } else {
                        options = new String[1];
                        options[0] = "end";
                    }
                }
            }
            if (options == null) {
                options = new String[1];
                options[0] = "end";
            }

            validInput = false;
            // get the initial action
            String userInput = controller.getAction(options, null, null, null);

            //handles the different forms of user input
            switch (userInput) {
            case "move":
                // get which set they want to move to
                String[] adjSets;
                if (activePlayer.getSet().equals("office")) {
                    adjSets = castingOfficeSet.getAdjSets();
                } else {
                    Sets currSet = findSet(activePlayer.getSet(), sets);
                    adjSets = currSet.getAdjSets();
                }
                options = new String[2];
                options[0] = "set";
                options[1] = "cancel";
                userInput = controller.getAction(options, adjSets, null, null);
                if (!userInput.equals("cancel")) {
                    if (movedAlready) {
                        controller.printMessage("You can only move once per turn.");
                    } else if (activePlayer.getRole() == null) {
                        String givenSet = userInput;
                        Sets getSet;
                        // moving TO the office
                        if (givenSet.equals("office")) {
                            Sets currentSet = findSet(activePlayer.getSet(), sets);
                            int occupancy = castingOfficeSet.getOccupancy();
                            int[] playerPlacement = castingOfficeSet.getPlayerPlacement(occupancy);
                            // moving player from the set they're on
                            if (currentSet.isAdjSet("office")) {
                                Sets oldSet = findSet(activePlayer.getSet(), sets);
                                oldSet.removePlayer(activePlayer);

                                // moving the player to the office
                                activePlayer.moveToSet("office");
                                castingOfficeSet.addPlayer(activePlayer);
                                controller.move(activePlayer, playerArray, playerPlacement);
                                validInput = true;
                                movedAlready = true;
                            } else {
                                controller.printMessage("That is not an adjacent set!");
                            }
                        } else if ((getSet = findSet(givenSet, sets)) != null) {
                            if (getSet.isAdjSet(activePlayer.getSet())) {
                                // moving from casting office
                                if (activePlayer.getSet() != null && activePlayer.getSet().equals("office")) {
                                    castingOfficeSet.removePlayer(activePlayer);
                                    // moving from set
                                } else if (activePlayer.getSet() != null) {
                                    Sets oldSet = findSet(activePlayer.getSet(), sets);
                                    oldSet.removePlayer(activePlayer);
                                }
                                // moving player to the given set
                                activePlayer.moveToSet(givenSet);
                                getSet.addPlayer(activePlayer);
                                int occupancy = getSet.getOccupancy();
                                int[] playerPlacement = getSet.getPlayerPlacement(occupancy);
                                controller.move(activePlayer, playerArray, playerPlacement);
                                controller.printMessage(activePlayer.getName() + " moved to the set " + userInput + ".");
                                validInput = true;
                                movedAlready = true;
                            } else {
                                controller.printMessage(userInput + " is not an adjacent set.");
                                validInput = true;
                            }
                        } else {
                            controller.printMessage(userInput + " is not a valid set.");
                        }
                    } else {
                        controller.printMessage("You cannot move, you are currently working!");
                    }
                } else if (userInput.equals("cancel")) {
                    userInput = null;
                } else {
                    controller.printMessage("Improper command usage. Type 'help' for more info.");
                }
                break;
            // player wishes to end their turn
            case "end":
                for (int i = 0; i < playerArray.length; i++) {
                    if (playerArray[i] == activePlayer) {
                        if (i + 1 == playerArray.length) {
                            activePlayer = playerArray[0];
                            break;
                        } else {
                            activePlayer = playerArray[i + 1];
                            break;
                        }
                    }
                }
                movedAlready = false;
                actedAlready = false;
                rehearsedAlready = false;
                tookRole = false;
                controller.updateActive(activePlayer);
                controller.updatePlayerPanel(playerArray);
                controller.printMessage("The active player is now " + activePlayer.getName());
                break;
            //player wishes to take a role
            case "work":
                if (activePlayer.getRole() == null) {
                    Sets playerSet = findSet(activePlayer.getSet(), sets);
                    options = new String[2];
                    options[0] = "roles";
                    options[1] = "cancel";
                    //getting all the roles for the player 
                    Roles[] setRoles = playerSet.getRoles();
                    Roles[] cardRoles = playerSet.getSceneCard().getRoles();
                    Roles[] allRoles = new Roles[setRoles.length + cardRoles.length];

                    for (int i = 0; i < setRoles.length; i++) {
                        allRoles[i] = setRoles[i];
                    }
                    for (int i = 0; i < cardRoles.length; i++) {
                        allRoles[i + setRoles.length] = cardRoles[i];
                    }
                    //getting role choice from player
                    userInput = controller.getAction(options, null, allRoles, null);

                    //validating and assigning role
                    Roles newRole = playerSet.getRole(userInput);
                    if (newRole != null && activePlayer.getRank() >= newRole.getRoleRank() && !newRole.getTaken()) {
                        activePlayer.setRole(newRole);
                        newRole.setTaken(true);
                        tookRole = true;
                        controller.takeRole(activePlayer, newRole, playerArray, playerSet.getCardPlacement());
                        controller.printMessage(activePlayer.getName() + " took the role " + newRole.getName());
                    } else if (userInput.equals("cancel")) {
                        userInput = null;
                    } else {
                        controller.printMessage("You cannot work that role.");
                    }
                } else {
                    controller.printMessage("You are already working a role right now.");
                }
                break;
            //if the player wishes to act
            case "act":
                if (tookRole) {
                    controller.printMessage("You just took a role, you cannot act now.");
                } else if (!actedAlready && !rehearsedAlready) {
                    boolean passed = makeActCheck(activePlayer, sets, controller);
                    if (passed) {
                        Sets actingSet = findSet(activePlayer.getSet(), sets);
                        controller.removeShotTokens(actingSet.removeShotTokens());
                        controller.updateActive(activePlayer);
                        if (actingSet.getShotTokens() == 0) {
                            controller.printMessage("The last shot was taken. That's a wrap!");
                            actingSet.wrapScene(controller);
                            numSceneCards--;
                        }
                    }
                    actedAlready = true;
                } else {
                    controller.printMessage("You already acted or rehearsed this turn.");
                }
                break;
            //if the player wishes to rehearse
            case "rehearse":
                if (tookRole) {
                    controller.printMessage("You just took a role, you cannot rehearse now.");
                } else if (!rehearsedAlready && !actedAlready) {
                    boolean passed = rehearse(activePlayer, sets, controller);
                    if (passed) {
                        controller.printMessage("Successfully rehearsed!");
                    }
                    rehearsedAlready = true;
                } else {
                    controller.printMessage("You already acted or rehearsed this turn.");
                }
                break;
            //if the player wants to upgrade their rank
            case "upgradeTo":
                if (activePlayer.getSet() == "office") {
                    // getting all of the rank options for that player
                    int money = activePlayer.getMoney();
                    int credits = activePlayer.getCredits();
                    int[][] rankPrices = castingOfficeSet.getRankValues();
                    ArrayList<Integer> possibleRanks = new ArrayList<Integer>();

                    for (int i = 0; i < rankPrices.length; i++) {
                        if (rankPrices[0][i] > activePlayer.getRank()) {
                            if (money >= rankPrices[1][i]) {
                                possibleRanks.add(rankPrices[0][i]);
                            } else if (credits >= rankPrices[2][i]) {
                                possibleRanks.add(rankPrices[0][i]);
                            }
                        }
                    }

                    // turning that array list into an int[]
                    int[] rankOptions = new int[possibleRanks.size()];
                    for (int i = 0; i < rankOptions.length; i++) {
                        rankOptions[i] = possibleRanks.get(i);
                    }
                    options = new String[2];
                    options[0] = "ranks";
                    options[1] = "cancel";
                    boolean dollar = false;
                    boolean credit = false;
                    //getting rank choice from player
                    userInput = controller.getAction(options, null, null, rankOptions);
                    if (userInput != null && !userInput.equals("cancel")) {
                        int rankVal = Integer.parseInt(userInput);
                        if (activePlayer.getRank() >= rankVal) {
                            controller.printMessage("That rank is not an upgrade!");
                        } else {
                            for (int i = 0; i < rankPrices.length; i++) {
                                if (rankVal == rankPrices[0][i]) {
                                    if (money >= rankPrices[1][i]) {
                                        dollar = true;
                                    }
                                    if (credits >= rankPrices[2][i]) {
                                        credit = true;
                                    }
                                }
                            }
                            if (dollar && credit) {
                                options = new String[3];
                                options[0] = "dollar";
                                options[1] = "credit";
                                options[2] = "cancel";
                            } else if (dollar || credit) {
                                options = new String[2];
                                if (dollar) {
                                    options[0] = "dollar";
                                } else if (credit) {
                                    options[0] = "credit";
                                }
                                options[1] = "cancel";
                            } else {
                                options = new String[1];
                                options[0] = "cancel";
                            }
                            //getting payment choice from player
                            userInput = controller.getAction(options, null, null, null);
                            if (userInput.equals("dollar")) {
                                castingOfficeSet.upgradeRank(rankVal, userInput, money, activePlayer);
                            } else if (userInput.equals("credit")) {
                                castingOfficeSet.upgradeRank(rankVal, userInput, credits, activePlayer);
                            } else {
                                userInput = null;
                            }
                        }
                    } else {
                        userInput = null;
                    }
                }
                break;
            }
        }
    }

}
