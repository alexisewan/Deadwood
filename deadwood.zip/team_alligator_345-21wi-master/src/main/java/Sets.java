import java.util.*;

public class Sets {
   private String name;
   private String[] adjacentSets;
   private ArrayList<int[]> takes = new ArrayList<int[]>();
   private int shotTokens;
   private Roles[] roles;
   private SceneCards sceneCard;
   private ArrayList<Player> players = new ArrayList<Player>();
   private int[] cardPlacement = new int[4];

   private int[][] trailerPlacement = { { 680, 265, 27, 27 }, { 720, 265, 27, 27 }, { 760, 265, 27, 27 },
         { 680, 230, 27, 27 }, { 720, 230, 27, 27 }, { 760, 235, 27, 27 }, { 740, 200, 27, 27 }, { 700, 200, 27, 27 } };
   private int[][] secretHideouPlacement = { { 165, 540, 27, 27 }, { 195, 540, 27, 27 }, { 225, 540, 27, 27 },
         { 255, 540, 27, 27 }, { 165, 570, 27, 27 }, { 195, 570, 27, 27 }, { 225, 570, 27, 27 }, { 255, 570, 27, 27 } };
   private int[][] trainStationPlacement = { { 7, 145, 27, 27 }, { 40, 145, 27, 27 }, { 7, 175, 27, 27 },
         { 7, 205, 27, 27 }, { 7, 235, 27, 27 }, { 7, 265, 27, 27 }, { 80, 265, 27, 27 }, { 130, 7, 27, 27 } };
   private int[][] generalStorePlacement = { { 200, 265, 27, 27 }, { 230, 265, 27, 27 }, { 260, 265, 27, 27 },
         { 290, 265, 27, 27 }, { 320, 265, 27, 27 }, { 350, 265, 27, 27 }, { 380, 265, 27, 27 }, { 130, 235, 27, 27 } };
   private int[][] saloonPlacement = { { 420, 265, 27, 27 }, { 450, 265, 27, 27 }, { 480, 265, 27, 27 },
         { 510, 265, 27, 27 }, { 540, 265, 27, 27 }, { 570, 265, 27, 27 }, { 600, 265, 27, 27 }, { 630, 265, 27, 27 } };
   private int[][] churchPlacement = { { 500, 450, 27, 27 }, { 530, 450, 27, 27 }, { 560, 450, 27, 27 },
         { 530, 570, 27, 27 }, { 500, 570, 27, 27 }, { 470, 570, 27, 27 }, { 440, 570, 27, 27 }, { 410, 570, 27, 27 } };
   private int[][] hotelPlacement = { { 670, 305, 27, 27 }, { 700, 305, 27, 27 }, { 670, 335, 27, 27 },
         { 670, 365, 27, 27 }, { 670, 395, 27, 27 }, { 740, 420, 27, 27 }, { 770, 420, 27, 27 }, { 635, 460, 27, 27 } };
   private int[][] bankPlacement = { { 560, 310, 27, 27 }, { 560, 340, 27, 27 }, { 450, 400, 27, 27 },
         { 480, 400, 27, 27 }, { 510, 400, 27, 27 }, { 540, 400, 27, 27 }, { 570, 400, 27, 27 }, { 600, 400, 27, 27 } };
   private int[][] ranchPlacement = { { 180, 405, 27, 27 }, { 210, 405, 27, 27 }, { 240, 405, 27, 27 },
         { 180, 435, 27, 27 }, { 210, 435, 27, 27 }, { 240, 435, 27, 27 }, { 360, 350, 27, 27 }, { 360, 380, 27, 27 } };
   private int[][] mainStreetPlacement = { { 610, 45, 27, 27 }, { 520, 45, 27, 27 }, { 550, 45, 27, 27 },
         { 580, 45, 27, 27 }, { 610, 75, 27, 27 }, { 520, 75, 27, 27 }, { 550, 75, 27, 27 }, { 580, 75, 27, 27 } };
   private int[][] jailPlacement = { { 190, 110, 27, 27 }, { 220, 110, 27, 27 }, { 250, 110, 27, 27 },
         { 265, 140, 27, 27 }, { 295, 140, 27, 27 }, { 325, 140, 27, 27 }, { 335, 110, 27, 27 }, { 365, 110, 27, 27 } };

   public void Sets(String setName, String[] adjacentSets, ArrayList<int[]> takes, Roles[] roles, int[] setInfo) {
      this.name = setName;
      this.adjacentSets = adjacentSets;
      this.takes = takes;
      this.roles = roles;
      this.shotTokens = takes.size();
      this.cardPlacement = setInfo;
   }

   public String getName() {
      return this.name;
   }

   public String[] getAdjSets() {
      return this.adjacentSets;
   }

   public SceneCards getSceneCard() {
      return this.sceneCard;
   }

   public int getShotTokens() {
      return this.shotTokens;
   }

   public Roles[] getRoles() {
      return this.roles;
   }

   public ArrayList<int[]> getTakes() {
      return this.takes;
   }

   public int[] getCardPlacement() {
      return this.cardPlacement;
   }

   public int getOccupancy() {
      return this.players.size();
   }

   public Roles getRole(String roleName) {
      if (sceneCard != null) {
         for (int i = 0; i < roles.length; i++) {
            if (roles[i].getName().equals(roleName)) {
               return roles[i];
            }
         }
         Roles[] sceneRoles = this.sceneCard.getRoles();
         for (int i = 0; i < sceneRoles.length; i++) {
            if (sceneRoles[i].getName().equals(roleName)) {
               return sceneRoles[i];
            }
         }
      }
      return null;
   }

   public void addPlayer(Player player) {
      players.add(player);
   }

   public void removePlayer(Player player) {
      players.remove(player);
   }

   public void wrapScene(DeadwoodController controller) {
      Dice dice = new Dice();
      Bank bank = new Bank();
      int budget = this.sceneCard.getBudget();
      ArrayList<Integer> revenue = dice.bonusRoll(budget);
      int[] revenueArray = new int[revenue.size()];
      for (int i = 0; i < revenue.size(); i++) {
         revenueArray[i] = revenue.get(i);
      }
      // using insertion sort to sort the revenue array
      // implementation of insertion sort adpated from
      // https://www.javatpoint.com/insertion-sort-in-java
      for (int j = 1; j < revenueArray.length; j++) {
         int sorting = revenueArray[j];
         int i = j - 1;
         while ((i > -1) && sorting < revenueArray[i]) {
            revenueArray[i + 1] = revenueArray[i];
            i--;
         }
         revenueArray[i + 1] = sorting;
      }
      bank.payActors(players, revenueArray);
      for (int i = 0; i < players.size(); i++) {
         Roles removeRole = players.get(i).getRole();
         players.get(i).setRole(null);
         removeRole.setTaken(false);
      }
      controller.removeSceneCard(cardPlacement);
      this.sceneCard = null;
   }

   public int[] removeShotTokens() {
      int[] removeToken = takes.get(0);
      takes.remove(removeToken);
      shotTokens--;
      return removeToken;
   }

   public void removeSceneCard() {
      this.sceneCard = null;
   }

   public void dealNewScenes(ArrayList<Sets> sets, ArrayList<SceneCards> sceneCards, DeadwoodController controller) {
      for (int i = 0; i < sets.size(); i++) {
         Sets currentSet = sets.get(i);
         int size = sceneCards.size();
         if (!currentSet.getName().equals("trailer")) {
            int randomCard = 0;
            randomCard = (int) (Math.random() * size + 1);
            SceneCards card = sceneCards.get(randomCard - 1);
            currentSet.setSceneCard(card);
            controller.placeCard(currentSet.getCardPlacement(), card.getPNGLocation());
            sceneCards.remove(card);
         }
         ArrayList<int[]> currentTakes = currentSet.getTakes();
         for (int j = 0; j < currentTakes.size(); j++) {
            controller.addTakes(currentTakes.get(j));
         }
      }
   }

   public void setSceneCard(SceneCards card) {
      this.sceneCard = card;
   }

   public void printAdjacentSets() {
      System.out.println("The sets adjacent to you are:");
      for (int i = 0; i < adjacentSets.length; i++) {
         System.out.print(adjacentSets[i] + "  ");
      }
      System.out.println();
   }

   public boolean isAdjSet(String set) {
      for (int i = 0; i < adjacentSets.length; i++) {
         if (adjacentSets[i].equals(set)) {
            return true;
         }
      }
      return false;
   }

   public void displayRoles() {

      if (roles != null) {
         System.out.println("Extra roles:");
         for (int i = 0; i < roles.length; i++) {
            if (!roles[i].getTaken()) {
               roles[i].printRole();
            }
         }
      }
      if (sceneCard != null) {
         System.out.println("Lead roles:");
         Roles[] sceneRoles = sceneCard.getRoles();
         for (int i = 0; i < sceneRoles.length; i++) {
            if (!sceneRoles[i].getTaken()) {
               sceneRoles[i].printRole();
            }
         }
      }
   }

   public void printSet() {
      System.out.print(name + " ");
      System.out.print(takes + " ");
      for (int j = 0; j < adjacentSets.length; j++) {
         String adjSet = adjacentSets[j];
         System.out.print(adjSet + " ");
      }
      if (roles != null) {
         for (int i = 0; i < roles.length; i++) {
            Roles thisRole = roles[i];
            thisRole.printRole();
         }
      }
   }

   public int[] getPlayerPlacement(int occupancy) {
      int[][] places = this.getWholePlacementArray();
      return places[occupancy];
   }

   public int[][] getWholePlacementArray() {
      switch (this.name) {
      case "trailer":
         return trailerPlacement;
      case "Main Street":
         return mainStreetPlacement;
      case "Saloon":
         return saloonPlacement;
      case "Hotel":
         return hotelPlacement;
      case "Ranch":
         return ranchPlacement;
      case "Church":
         return churchPlacement;
      case "Secret Hideout":
         return secretHideouPlacement;
      case "Jail":
         return jailPlacement;
      case "Train Station":
         return trainStationPlacement;
      case "General Store":
         return generalStorePlacement;
      case "Bank":
         return bankPlacement;
      }
      return null;
   }
}
