import java.util.*;

public class CastingOffice {
  // 2d array with rank exchange rates. first row is ranks, second row is money,
  // third is credits
  private static int[][] rankValues = new int[3][5];
  private String[] adjacentSets;
  private ArrayList<Player> players = new ArrayList<Player>();
  private int[] officeInfo = new int[4];
  private static ArrayList<int[]> dollarAreas = new ArrayList<int[]>();
  private static ArrayList<int[]> creditAreas = new ArrayList<int[]>();
  private int[][] playerPlacement = { { 7, 330, 27, 27 }, { 7, 360, 27, 27 }, { 7, 390, 27, 27 }, { 7, 420, 27, 27 },
      { 115, 330, 27, 27 }, { 115, 360, 27, 27 }, { 115, 390, 27, 27 }, { 115, 420, 27, 27 } };

  public void CastingOffice(String[] adjacentSets, int[] officeArea) {
    this.adjacentSets = adjacentSets;
    this.officeInfo = officeArea;
  }

  // imports the given rank value, values come for the board.xml file
  public static void setRankValues(int rank, String currency, int price, int[] areas) {
    rankValues[0][rank - 2] = rank;
    if (currency.equals("dollar")) {
      rankValues[1][rank - 2] = price;
      dollarAreas.add(areas);
    } else if (currency.equals("credit")) {
      rankValues[2][rank - 2] = price;
      creditAreas.add(areas);
    }
  }

  public int[][] getRankValues() {
    return this.rankValues;
  }

  public void addPlayer(Player player) {
    players.add(player);
  }

  public void removePlayer(Player player) {
    players.remove(player);
  }

  public int[] getPlayerPlacement(int occupancy) {
    return this.playerPlacement[occupancy];
  }

  public int getOccupancy() {
    return players.size();
  }
  public String[] getAdjSets(){
    return this.adjacentSets;
  }

  public void printAdjacentSets() {
    System.out.println("The sets adjacent to you are:");
    for (int i = 0; i < adjacentSets.length; i++) {
      System.out.print(adjacentSets[i] + "  ");
    }
    System.out.println();
  }

  // displays all of the rank options and prices
  public static void getRankOptions(int rank, int money, int credits) {
    for (int i = 0; i < 5; i++) {
      System.out.println(
          "Rank " + rankValues[0][i] + " costs $" + rankValues[1][i] + " or " + rankValues[2][i] + " credits.");
    }
  }

  // upgrades a player's rank and takes payment
  public boolean upgradeRank(int rank, String paymentType, int payment, Player player) {
    int newRank = rank;
    for (int i = 0; i < 5; i++) {
      if (rankValues[0][i] == rank) {
        if (paymentType.equals("credit")) {
          if (payment >= rankValues[2][i]) {
            collectPayment(player, paymentType, rankValues[2][i]);
            int oldRank = player.getRank();
            System.out.println(player.getName() + " has upgraded from rank " + oldRank + " to rank " + newRank);
            player.setRank(newRank);
            return true;
          } else {
            return false;
          }
        } else {
          if (payment >= rankValues[1][i]) {
            collectPayment(player, paymentType, rankValues[1][i]);
            int oldRank = player.getRank();
            System.out.println(player.getName() + " has upgraded from rank " + oldRank + " to " + newRank);
            player.setRank(newRank);
            return true;
          } else {
            return false;
          }
        }
      }
    }
    return false;
  }

  // removes the given currency amount from the player's money or credits
  public void collectPayment(Player player, String currency, int price) {
    if (currency.equals("dollar")) {
      player.setMoney(player.getMoney() - price);
    } else if (currency.equals("credit")) {
      player.setCredits(player.getCredits() - price);
    }
  }
}