public class Roles {
   private String roleTitle;
   private int roleRank;
   private String lines;
   private String type;
   private boolean taken = false;
   // set roleInfo is relative to the board, card roleInfo is relative to the card.
   private int[] roleInfo = new int[4];

   public void Roles(String title, int rank, String lines, String type, int[] area) {
      this.roleTitle = title;
      this.roleRank = rank;
      this.lines = lines;
      this.type = type;
      this.roleInfo = area;
   }

   public void printRole() {
      System.out.print(roleTitle + " has a rank of ");
      System.out.print(roleRank + " with the line, '");
      System.out.println(lines + "'");
   }

   public String getName() {
      return this.roleTitle;
   }

   public String getLine() {
      return lines;
   }

   public String getType() {
      return this.type;
   }

   public int getRoleRank() {
      return this.roleRank;
   }

   public int[] getRoleInfo(){
      return this.roleInfo;
   }

   public boolean getTaken() {
      return this.taken;
   }

   public void setTaken(boolean taken) {
      this.taken = taken;
   }
}