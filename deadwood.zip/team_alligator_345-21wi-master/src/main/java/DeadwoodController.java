public class DeadwoodController {
    DeadwoodGUI deadwoodGUI = new DeadwoodGUI();

    public void runGUI(int numPlayers, Player activePlayer, Player[] allPlayers) {
        deadwoodGUI.run(numPlayers, activePlayer, allPlayers);
    }

    public int getPlayers() {
        int numPlayers = deadwoodGUI.numberOfPlayers();
        return numPlayers;
    }

    public String getName() {
        String name = deadwoodGUI.players();
        return name;
    }

    public void placeCard(int[] cardDims, String pngLocation) {
        deadwoodGUI.placeCard(cardDims, pngLocation);
    }

    public void move(Player player, Player[] players, int[] placement) {
        deadwoodGUI.move(player, players, placement);
    }

    public String getAction(String[] options, String[] adjSets, Roles[] roles, int[] rankOptions) {
        String action = deadwoodGUI.getAction(options, adjSets, roles, rankOptions);
        return action;
    }

    public void addTakes(int[] takeDims) {
        deadwoodGUI.addTakes(takeDims);
    }

    public void addDice(Player[] players, int[][] placement) {
        deadwoodGUI.addDice(players, placement);
    }

    public void updateActive(Player player) {
        deadwoodGUI.updateActive(player);
    }

    public void updatePlayerPanel(Player[] allPlayers) {
        deadwoodGUI.playerPanel(allPlayers);
    }

    public void updatePlayerDie(Player player, Player[] playerArray){
        deadwoodGUI.updatePlayerDie(player, playerArray);
    }

    public void takeRole(Player player, Roles roleInfo, Player[] players, int[] setInfo) {
        deadwoodGUI.takeRole(player, roleInfo, players, setInfo);
    }

    public void printMessage(String message) {
        deadwoodGUI.printMessage(message);
    }

    public void removeShotTokens(int[] shotInfo) {
        deadwoodGUI.removeShotTokens(shotInfo);
    }

    public void removeSceneCard(int[] cardPlacement) {
        deadwoodGUI.removeSceneCard(cardPlacement);
    }
}
