import javax.swing.*;
import javax.swing.border.*;

import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class DeadwoodGUI extends JFrame {
  /* Do not need main method bc the Deadwood.java file controls the main method */

  String input;
  // String strNames[] = { "Nikka", "Alexis", "Yum" };
  // String currentName;
  // String currentRank;
  // String currentPosition;
  // String currentRole;
  // String currentMoney;
  // String currentCredits;

  int numOfPlayers;

  JFrame frame;
  JFrame popup;
  JFrame popup2;

  JLabel board;
  JLayeredPane boardPanel;
  JPanel activePlayer;
  JPanel printActive = new JPanel(new GridLayout(0, 1));
  JPanel message;
  ArrayList<JLabel> messageMessages = new ArrayList<JLabel>();
  JPanel actionButtons;
  JPanel playerNames;
  JPanel printAll = new JPanel(new GridLayout(0, 4));
  JLabel[] dice;

  JLabel[] takes = new JLabel[22];
  int takesCount = 0;

  JLabel[] cards = new JLabel[10];
  int cardsCount = 0;

  JButton two;
  JButton three;
  JButton four;
  JButton five;
  JButton six;
  JButton seven;
  JButton eight;
  JButton submit;
  JButton move;
  JButton work;
  JButton act;
  JButton rehearse;
  JButton upgrade;
  JButton cancel;
  JButton dollar;
  JButton credit;
  JButton end;

  JLabel currPlayer;
  JLabel currRank;
  JLabel currPosition;
  JLabel currRole;
  JLabel currMoney;
  JLabel currCredits;

  JTextField players;
  String action;
  ClickButtonListener clickButtonListener = new ClickButtonListener();

  //displays the window that contains the board and information side panel
  public void run(int numOfPlayers, Player player1, Player[] allPlayers) {
    frame = new JFrame();
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.setTitle("Playing: Deadwood Studios, USA");
    frame.setSize(new Dimension(1220, 800));

    // getting the board image
    board = new JLabel();
    ImageIcon boardImg = new ImageIcon("board.png");
    Image img = boardImg.getImage().getScaledInstance(800, 600, Image.SCALE_SMOOTH);
    boardImg = new ImageIcon(img);
    board.setIcon(boardImg);

    // setting bounds for board and adding to lowest layer
    board.setBounds(0, 0, boardImg.getIconWidth(), boardImg.getIconHeight());

    // panel for the window on the right side
    JPanel sideWindow = new JPanel();
    sideWindow.setPreferredSize(new Dimension(400, 600));
    sideWindow.setLayout(new BoxLayout(sideWindow, BoxLayout.Y_AXIS));

    // subpanel 1
    // active player name and info will be printed here
    activePlayer = new JPanel(new GridLayout(0, 1));
    activePlayer.setBorder(BorderFactory.createTitledBorder("Active Player"));
    ((javax.swing.border.TitledBorder) activePlayer.getBorder()).setTitleFont(new Font("", Font.BOLD, 18));
    activePlayer.setPreferredSize(new Dimension(375, 50));

    updateActive(player1);

    // subpanel 2
    // messages for the player
    message = new JPanel();
    message.setBorder(BorderFactory.createTitledBorder("Message"));
    ((javax.swing.border.TitledBorder) message.getBorder()).setTitleFont(new Font("", Font.BOLD, 18));
    message.setPreferredSize(new Dimension(375, 50));

    // subpanel 3
    // action items for player
    actionButtons = new JPanel();
    actionButtons.setBorder(BorderFactory.createTitledBorder("Actions"));
    ((javax.swing.border.TitledBorder) actionButtons.getBorder()).setTitleFont(new Font("", Font.BOLD, 18));
    actionButtons.setPreferredSize(new Dimension(375, 50));

    // subpanel 4
    // insert list of players
    playerNames = new JPanel(new GridLayout(0, 1));
    playerNames.setBorder(BorderFactory.createTitledBorder("Players"));
    ((javax.swing.border.TitledBorder) playerNames.getBorder()).setTitleFont(new Font("", Font.BOLD, 18));
    playerNames.setPreferredSize(new Dimension(375, 50));

    JPanel panel = new JPanel(new GridLayout(0, 4));
    JLabel pNames = new JLabel("<HTML><U>Players</U></HTML>");
    JLabel pRanks = new JLabel("<HTML><U>Ranks</U></HTML>");
    JLabel pMoney = new JLabel("<HTML><U>Money</U></HTML>");
    JLabel pCredits = new JLabel("<HTML><U>Credits</U></HTML>");

    panel.add(pNames);
    panel.add(pRanks);
    panel.add(pMoney);
    panel.add(pCredits);

    playerNames.add(panel, BorderLayout.NORTH);

    playerPanel(allPlayers);

    // sideWindow.add(label);
    sideWindow.add(activePlayer);
    sideWindow.add(message);
    sideWindow.add(actionButtons);
    sideWindow.add(playerNames);

    boardPanel = new JLayeredPane();
    boardPanel.setLayout(null);
    boardPanel.add(board, (Integer) 0);

    frame.add(sideWindow);
    frame.getContentPane().add(BorderLayout.CENTER, boardPanel);
    frame.getContentPane().add(BorderLayout.EAST, sideWindow);
    frame.setVisible(true);
  }

  // popup menu asking user for number of players
  public int numberOfPlayers() {

    popup = new JFrame("Deadwood, USA");
    popup.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    JPopupMenu pop = new JPopupMenu();
    JPanel options = new JPanel(new GridLayout(4, 2));

    JLabel num = new JLabel("Number of Players:");
    num.setPreferredSize(new Dimension(100, 50));

    // number of players
    two = new JButton("2");
    three = new JButton("3");
    four = new JButton("4");
    five = new JButton("5");
    six = new JButton("6");
    seven = new JButton("7");
    eight = new JButton("8");

    options.add(num);
    options.add(two);
    options.add(three);
    options.add(four);
    options.add(five);
    options.add(six);
    options.add(seven);
    options.add(eight);

    two.addActionListener(clickButtonListener);
    three.addActionListener(clickButtonListener);
    four.addActionListener(clickButtonListener);
    five.addActionListener(clickButtonListener);
    six.addActionListener(clickButtonListener);
    seven.addActionListener(clickButtonListener);
    eight.addActionListener(clickButtonListener);

    num.setHorizontalAlignment(JLabel.CENTER);
    popup.getContentPane().add(BorderLayout.NORTH, num);

    popup.getContentPane().add(options);
    popup.setSize(400, 300);

    try {
      synchronized (popup) {
        while (numOfPlayers == 0) {
          popup.setVisible(true);
          popup.wait();
        }
      }
    } catch (InterruptedException e) {
      System.out.println("Did not work");
    }

    popup.setVisible(false);
    // return the number of players received from the pop-up
    return numOfPlayers;
  }

  // popup menu that asks for player names
  public String players() {

    popup2 = new JFrame("Deadwood, USA");
    popup2.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    JPanel options2 = new JPanel();

    JLabel names = new JLabel("Player Name:");
    names.setPreferredSize(new Dimension(120, 10));
    players = new JTextField();
    players.setPreferredSize(new Dimension(200, 40));

    submit = new JButton("Submit");
    submit.addActionListener(clickButtonListener);

    options2.add(names);
    options2.add(players);
    options2.add(submit);

    popup2.getContentPane().add(BorderLayout.CENTER, options2);
    popup2.setSize(400, 150);

    try {
      synchronized (popup2) {
        for (int i = 1; i <= 1; i++) {
          popup2.setVisible(true);
          popup2.wait();
        }
      }
    } catch (InterruptedException e) {
      System.out.println("Did not work");
    }

    popup2.setVisible(false);
    return input;

  }

  //initialize the player's dice
  public void addDice(Player[] playerArray, int[][] trailerPlacement) {
    dice = new JLabel[numOfPlayers];
    String[] playerDice = { "dice_b", "dice_c", "dice_g", "dice_o", "dice_p", "dice_r", "dice_v", "dice_w", "dice_y" };
    for (int i = 0; i < playerArray.length; i++) {
      playerArray[i].setDieColor(playerDice[i]);
      int rank = playerArray[i].getRank();
      String color = playerDice[i];
      color += rank;
      color += ".png";

      //adding the image
      JLabel die = new JLabel();
      ImageIcon dieImg = new ImageIcon(color);
      Image img = dieImg.getImage().getScaledInstance(27, 27, Image.SCALE_SMOOTH);
      dieImg = new ImageIcon(img);
      die.setIcon(dieImg);
      dice[i] = die;

      boardPanel.add(dice[i], (Integer) 2);
      dice[i].setBounds(trailerPlacement[i][0], trailerPlacement[i][1], trailerPlacement[i][2], trailerPlacement[i][3]);
    }
  }

  //displays an image of a clapper at the given location
  public void addTakes(int[] takeDims) {
    JLabel take = new JLabel();
    // getting the board image
    ImageIcon takeImg = new ImageIcon("shot.png");
    Image img = takeImg.getImage().getScaledInstance(takeDims[2], takeDims[3], Image.SCALE_SMOOTH);
    takeImg = new ImageIcon(img);
    take.setIcon(takeImg);

    takes[takesCount] = take;
    takesCount++;

    boardPanel.add(take, (Integer) 1);
    take.setBounds(takeDims[0], takeDims[1], takeDims[2], takeDims[3]);
  }

  //displays an image of the given scene card at the given location
  public void placeCard(int[] cardDims, String pngLocation) {
    JLabel card = new JLabel();
    // getting the card image
    ImageIcon cardImg = new ImageIcon(pngLocation);
    Image img = cardImg.getImage().getScaledInstance(cardDims[3], cardDims[2], Image.SCALE_SMOOTH);
    cardImg = new ImageIcon(img);
    card.setIcon(cardImg);

    cards[cardsCount] = card;
    cardsCount++;

    boardPanel.add(card, (Integer) 1);
    card.setBounds(cardDims[0], cardDims[1], cardDims[3], cardDims[2]);
  }

  //moving the player's die icon
  public void move(Player player, Player[] playerArray, int[] placement) {
    // move player's icon from one set to the next
    for (int i = 0; i < numOfPlayers; i++) {
      if (playerArray[i] == player) {
        dice[i].setBounds(placement[0], placement[1], placement[2], placement[3]);
      }
    }
  }

  //displays buttons for user to decide what actions to take on their turn
  public String getAction(String[] options, String[] adjSets, Roles[] roles, int[] rankOptions) {
    ArrayList<JButton> buttons = new ArrayList<JButton>();
    for (int k = 0; k < options.length; k++) {
      switch (options[k]) {
      case "move":
        move = new JButton("Move");
        move.addActionListener(clickButtonListener);
        actionButtons.add(move);
        buttons.add(move);
        break;
      case "set":
        for (int i = 0; i < adjSets.length; i++) {
          JButton adjSetsButton = new JButton(adjSets[i]);
          adjSetsButton.addActionListener(clickButtonListener);
          actionButtons.add(adjSetsButton);
          buttons.add(adjSetsButton);
        }
        break;
      case "work":
        work = new JButton("Work");
        work.addActionListener(clickButtonListener);
        actionButtons.add(work);
        buttons.add(work);
        break;
      case "roles":
        for (int i = 0; i < roles.length; i++) {
          JButton role = new JButton(roles[i].getName());
          role.addActionListener(clickButtonListener);
          actionButtons.add(role);
          buttons.add(role);

        }
        break;
      case "act":
        act = new JButton("Act");
        act.addActionListener(clickButtonListener);
        actionButtons.add(act);
        buttons.add(act);

        break;
      case "rehearse":
        rehearse = new JButton("Rehearse");
        rehearse.addActionListener(clickButtonListener);
        actionButtons.add(rehearse);
        buttons.add(rehearse);

        break;
      case "upgrade":
        upgrade = new JButton("Upgrade Rank");
        upgrade.addActionListener(clickButtonListener);
        actionButtons.add(upgrade);
        buttons.add(upgrade);

        break;
      case "ranks":
        for (int l = 0; l < rankOptions.length; l++) {
          JButton rankButton = new JButton("" + rankOptions[l]);
          rankButton.addActionListener(clickButtonListener);
          actionButtons.add(rankButton);
          buttons.add(rankButton);

        }
        break;
      case "cancel":
        cancel = new JButton("cancel");
        cancel.addActionListener(clickButtonListener);
        actionButtons.add(cancel);
        buttons.add(cancel);
        break;
      case "dollar":
        dollar = new JButton("dollar");
        dollar.addActionListener(clickButtonListener);
        actionButtons.add(dollar);
        buttons.add(dollar);
        break;
      case "credit":
        credit = new JButton("credit");
        credit.addActionListener(clickButtonListener);
        actionButtons.add(credit);
        buttons.add(credit);
        break;
      case "end":
        end = new JButton("End turn");
        end.addActionListener(clickButtonListener);
        actionButtons.add(end);
        buttons.add(end);
        break;
      }

    }

    action = null;
    try {
      synchronized (actionButtons) {
        while (action == null) {
          frame.setVisible(true);
          actionButtons.wait();
        }
      }
    } catch (

    InterruptedException e) {
      System.out.println("Did not work");
    }
    for (int i = 0; i < buttons.size(); i++) {
      buttons.get(i).setVisible(false);
    }
    buttons = null;
    actionButtons.removeAll();
    return action;
  }

  // updates the "Active Player" panel to reflect the info of the active player
  public void updateActive(Player player) {
    printActive.setVisible(false);
    activePlayer.remove(printActive);
    printActive = null;
    printActive = new JPanel(new GridLayout(0, 1));

    Roles role = player.getRole();

    currPlayer = new JLabel("Player: " + player.getName());
    currRank = new JLabel("Rank: " + player.getRank());
    currMoney = new JLabel("Money: " + player.getMoney());
    currCredits = new JLabel("Credits: " + player.getCredits());

    printActive.add(currPlayer);
    printActive.add(currRank);
    if (player.getSet() != null) {
      currPosition = new JLabel("Location: " + player.getSet());
      printActive.add(currPosition);
    } else {
      JLabel currLocation = new JLabel("Location: ");
      printActive.add(currLocation);
    }
    if (role != null) {
      currRole = new JLabel("Role: " + role.getName());
      printActive.add(currRole);
    } else {
      JLabel currRole = new JLabel("Role: ");
      printActive.add(currRole);
    }
    printActive.add(currMoney);
    printActive.add(currCredits);

    activePlayer.add(printActive);
  }

  //updating the image after a user upgrades their rank. This method
  //does not work as it is supposed to and we did not have time to 
  //figure out the issue.
  public void updatePlayerDie(Player player, Player[] playerArray) {
    for (int i = 0; i < numOfPlayers; i++) {
      if (playerArray[i] == player) {
        String pngLocation = player.getDieColor();
        pngLocation += player.getRank();
        pngLocation += ".png";

        dice[i].setVisible(false);
        int[] dimensions = new int[4];
        dimensions[0] = dice[i].getX();
        dimensions[1] = dice[i].getY();
        dimensions[2] = dice[i].getHeight();
        dimensions[3] = dice[i].getWidth();
        boardPanel.remove(dice[i]);

        JLabel die = new JLabel();
        ImageIcon dieImg = new ImageIcon(pngLocation);
        Image img = dieImg.getImage().getScaledInstance(27, 27, Image.SCALE_SMOOTH);
        dieImg = new ImageIcon(img);
        die.setIcon(dieImg);
        dice[i] = die;

        boardPanel.add(dice[i], (Integer) 2);
        dice[i].setBounds(dimensions[0], dimensions[1], dimensions[2], dimensions[3]);

      }
    }
  }

  // moves a player's die to the designated role area
  public void takeRole(Player player, Roles role, Player[] players, int[] setInfo) {
    int[] roleInfo = role.getRoleInfo();
    for (int i = 0; i < numOfPlayers; i++) {
      if (players[i] == player) {
        //adjusting for the card's role coordinates. there is an error in our logic here
        if (role.getType().equals("card")) {
          roleInfo[0] += setInfo[0];
          roleInfo[1] += setInfo[1];
        }
        dice[i].setBounds(roleInfo[0], roleInfo[1], roleInfo[2], roleInfo[3]);
      }
    }
  }

  // prints the given message to the message panel
  public void printMessage(String print) {
    message.revalidate();
    message.repaint();
    message.removeAll();

    message.add(new JLabel(""));
    message.add(new JLabel(print));
  }

  // updates the player panel after a player has ended their turn
  public void playerPanel(Player[] allPlayers) {
    printAll.setVisible(false);
    playerNames.remove(printAll);
    printAll = null;
    printAll = new JPanel(new GridLayout(0, 4));

    for (int i = 0; i < allPlayers.length; i++) {

      JLabel allNames = new JLabel("" + allPlayers[i].getName());
      JLabel allRanks = new JLabel("" + allPlayers[i].getRank());
      JLabel allMoney = new JLabel("" + allPlayers[i].getMoney());
      JLabel allCredits = new JLabel("" + allPlayers[i].getCredits());

      printAll.add(allNames);
      printAll.add(allRanks);
      printAll.add(allMoney);
      printAll.add(allCredits);
      playerNames.add(printAll);
    }
  }

  // removes the shot token img at the given Position
  public void removeShotTokens(int[] shotInfo) {
    for (int i = 0; i < takes.length; i++) {
      if (takes[i].getX() == shotInfo[0]) {
        if (takes[i].getY() == shotInfo[1]) {
          takes[i].setVisible(false);
          boardPanel.remove(takes[i]);
          break;
        }
      }
    }
  }

  //removes the scene card img at the given position
  public void removeSceneCard(int[] cardPlacement) {
    for (int i = 0; i < takes.length; i++) {
      if (cards[i].getX() == cardPlacement[0]) {
        if (cards[i].getY() == cardPlacement[1]) {
          cards[i].setVisible(false);
          boardPanel.remove(cards[i]);
          break;
        }
      }
    }
  }

  // activates the buttons/textfields
  private class ClickButtonListener implements ActionListener {

    @Override
    public void actionPerformed(ActionEvent e) {

      // get player input from JTextField
      if (e.getSource() == submit) {
        String str = e.getActionCommand();
        input = players.getText();
        players.setText("");
        synchronized (popup2) {
          popup2.notify();
        }
      }
    
      //These are all of the reactions for each button
      else if (e.getSource() == two) {
        numOfPlayers = 2;
        synchronized (popup) {
          popup.notify();
        }
      } else if (e.getSource() == three) {
        numOfPlayers = 3;
        synchronized (popup) {
          popup.notify();
        }
      } else if (e.getSource() == four) {
        numOfPlayers = 4;
        synchronized (popup) {
          popup.notify();
        }
      } else if (e.getSource() == five) {
        numOfPlayers = 5;
        synchronized (popup) {
          popup.notify();
        }
      } else if (e.getSource() == six) {
        numOfPlayers = 6;
        synchronized (popup) {
          popup.notify();
        }
      } else if (e.getSource() == seven) {
        numOfPlayers = 7;
        synchronized (popup) {
          popup.notify();
        }
      } else if (e.getSource() == eight) {
        numOfPlayers = 8;
        synchronized (popup) {
          popup.notify();
        }
      }

      else if (e.getSource() == move) {
        action = "move";
        synchronized (actionButtons) {
          actionButtons.notify();
        }
      } else if (e.getSource() == act) {
        action = "act";
        synchronized (actionButtons) {
          actionButtons.notify();
        }
      } else if (e.getSource() == rehearse) {
        action = "rehearse";
        synchronized (actionButtons) {
          actionButtons.notify();
        }
      } else if (e.getSource() == work) {
        action = "work";
        synchronized (actionButtons) {
          actionButtons.notify();
        }
      } else if (e.getSource() == upgrade) {
        action = "upgradeTo";
        synchronized (actionButtons) {
          actionButtons.notify();
        }
      } else if (e.getSource() == cancel) {
        action = "cancel";
        synchronized (actionButtons) {
          actionButtons.notify();
        }
      } else if (e.getSource() == dollar) {
        action = "dollar";
        synchronized (actionButtons) {
          actionButtons.notify();
        }
      } else if (e.getSource() == credit) {
        action = "credit";
        synchronized (actionButtons) {
          actionButtons.notify();
        }
      } else if (e.getSource() == end) {
        action = "end";
        synchronized (actionButtons) {
          actionButtons.notify();
        }
      } else {
        // return the text on the button
        // used for non-hard coded values like set names, roles, and rank options
        action = ((JButton) e.getSource()).getText();
        synchronized (actionButtons) {
          actionButtons.notify();
        }
      }

    }

  }

}
