import java.util.*;

public class Dice {

   // rolling the dice
   public static int diceRoll() {
      int roll = 0;
      roll = (int) (Math.random() * 6 + 1);
      return roll;
   }

   // keep number of dice in an array list for the end of scene to collect bonuses
   // bonusRoll is number of dice to be rolled
   public static ArrayList<Integer> bonusRoll(int numDice) {
      ArrayList<Integer> diceArr = new ArrayList<Integer>();
      int roll = 0;
      while (numDice != 0) {
         roll = (int) (Math.random() * 6 + 1);
         diceArr.add(roll);
         numDice--;
      }
      return diceArr;
   }
}
