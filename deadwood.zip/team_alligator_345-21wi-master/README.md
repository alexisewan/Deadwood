Repository for Nikka & Alexis
The game compiles using ./compile.sh with 0 arguments, and the game runs with the usage of ./run.sh [path/to/board.xml] [path/to/cards.xml]. All other necessary values come from the inputs provided by the user during runtime. 
