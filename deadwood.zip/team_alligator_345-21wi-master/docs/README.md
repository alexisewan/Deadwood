
Folder for design documents and any other documentation/notes.
